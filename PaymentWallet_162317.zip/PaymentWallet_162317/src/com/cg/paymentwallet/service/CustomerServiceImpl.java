package com.cg.paymentwallet.service;

import com.cg.paymentwallet.bean.AccountBean;
import com.cg.paymentwallet.dao.CustomerDAOImpl;
import com.cg.paymentwallet.dao.ICustomerDAO;
import com.cg.paymentwallet.exception.CustomerException;
import com.cg.paymentwallet.exception.CustomerMessage;

public class CustomerServiceImpl implements ICustomerService {

	ICustomerDAO dao=new CustomerDAOImpl();
	@Override
	public boolean createAccount(AccountBean accountBean) throws CustomerException {

		boolean isAdded=false;
		if(validateCreateAccount(accountBean)){
			isAdded=dao.createAccount(accountBean);
		}
		
		return isAdded;
	}

	@Override
	public AccountBean showBalance(int accountId) {
		// TODO Auto-generated method stub
		
		return dao.showBalance(accountId);
	}

	@Override
	public boolean deposit(AccountBean accountBean,int accountId,double depositAmount) {
		// TODO Auto-generated method stub
		
		return dao.deposit(accountBean,accountId,depositAmount);
	}

	@Override
	public boolean withdraw(AccountBean accountBean,int accountId,double withdrawAmount) {
		// TODO Auto-generated method stub
		
		return dao.withdraw(accountBean,accountId,withdrawAmount);
	}

	@Override
	public boolean fundTransfer(AccountBean toAccountBean,
			AccountBean fromAccountBean, double amount) {
		// TODO Auto-generated method stub
		
		return dao.fundTransfer(toAccountBean, fromAccountBean, amount);
	}

	@Override
	public AccountBean find(int accountId) {
		// TODO Auto-generated method stub
		AccountBean accountBean=dao.find(accountId);
		return accountBean;
	}

	
boolean validateCreateAccount(AccountBean accountBean) throws CustomerException{
	boolean isValid=false;
	String alphaRegex = ".*[A-Z].*";

	  if(accountBean.getAccountId()==0){
		  throw new CustomerException(CustomerMessage.ACCNUMBERERROR);
	  }
	  else if(accountBean.getCustomer().getFirstName().trim().length()==0){
		  throw new CustomerException(CustomerMessage.FNAMEERROR1);
	  }
	  else if(!(accountBean.getCustomer().getFirstName().matches("[A-Za-z]{4,}"))){
		  throw new CustomerException(CustomerMessage.FNAMEERROR2);
	  }
	  else if(accountBean.getCustomer().getMobileNumber().matches(alphaRegex)){
		  throw new CustomerException(CustomerMessage.MOBILENUMERROR1);
	  }
	  else if(!(accountBean.getCustomer().getMobileNumber().trim().length()==10)){
		  throw new CustomerException(CustomerMessage.MOBILENUMERROR2);
	  }
	  else if(accountBean.getCustomer().getPanNum().trim().length()==0){
		  throw new CustomerException(CustomerMessage.PANNUMERROR);
	  }
	  else if(accountBean.getCustomer().getAddress().trim().length()==0){
		  throw new CustomerException(CustomerMessage.ADDRESSERROR);
	  }
	  else if(accountBean.getCustomer().getEmailId().trim().length()==0){
		  throw new CustomerException(CustomerMessage.EMAILERROR);
	  }
	  else{
		  isValid=true;
	  }
	return isValid;
	
}


}
