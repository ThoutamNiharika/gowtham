package com.cg.paymentwallet.service;



import com.cg.paymentwallet.bean.AccountBean;
import com.cg.paymentwallet.exception.CustomerException;


public interface ICustomerService {

 public	boolean createAccount(AccountBean accountBean) throws CustomerException;
	
 public AccountBean showBalance(int accountId);
	
 public	boolean deposit(AccountBean accountBean,int accountId,double depositAmount);
	
 public	boolean withdraw(AccountBean accountBean,int accountId,double withdrawAmount);
	
 public	boolean fundTransfer(AccountBean toAccountBean,AccountBean fromAccountBean,double amount);

 public AccountBean find(int accountId);
}
