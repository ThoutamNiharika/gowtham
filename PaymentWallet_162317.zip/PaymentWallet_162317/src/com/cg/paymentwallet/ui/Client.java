package com.cg.paymentwallet.ui;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.paymentwallet.bean.AccountBean;
import com.cg.paymentwallet.bean.Customer;
import com.cg.paymentwallet.bean.WalletTransactions;
import com.cg.paymentwallet.service.CustomerServiceImpl;
import com.cg.paymentwallet.service.ICustomerService;

public class Client {
	ICustomerService service = new CustomerServiceImpl();
	Scanner scanner = new Scanner(System.in);
	AccountBean accountBean=new AccountBean();
	
	public static void main(String[] args) throws Exception {
		Client client = new Client();

		while (true) {
			System.out.println("****--Welcome to Bank--****");
			System.out
					.println("\n 1. Create Account \n 2. Show Balance \n 3. Deposit \n 4. WithDraw \n 5. Fund Transfer \n 6. Print Transactions \n 7. Exit");
			System.out.println("Enter your choice:");
			int choice = client.scanner.nextInt();
			switch (choice) {
			case 1: client.createAccount();

				break;

			case 2:client.showBalance();

				break;

			case 3:client.deposit();

				break;

			case 4:client.withdraw();

				break;

			case 5:client.fundTransfer();
				break;

			case 6:client.printTransaction();

				break;

			case 7:
				System.out.println("Thank You !!! Please visit us again");
				System.exit(0);

				break;

			default:
				System.out.println("Please enter valid option");
				break;
			}
		}
	}

	void createAccount() throws Exception {
		
		Customer customer=new Customer();
		
		System.out.println("Enter your first name:");
		String firstName = scanner.next();
		customer.setFirstName(firstName);
		
		System.out.println("Enter your last name:");
		String lastName = scanner.next();
		customer.setLastName(lastName);
		
		System.out.println("Enter your mobile number:");
		String mobileNumber = scanner.next();
		customer.setMobileNumber(mobileNumber);
		
		System.out.println("Enter your pan number:");
		String panNum = scanner.next();
		customer.setPanNum(panNum);
		
		System.out.println("Enter Email Id:");
		String emailId=scanner.next();
		customer.setEmailId(emailId);
		
		System.out.println("Enter your address:");
		String address = scanner.next();
		customer.setAddress(address);
		
		AccountBean accountBean=new AccountBean();
		int accountId=(int) (Math.random()*1000000);
        accountBean.setAccountId(accountId);
        
        System.out.println("Enter Date of Opening (DD/MM/YYYY)");
		String accDateInput=scanner.next();
		
		
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		Date dateOfOpening=sdf.parse(accDateInput);
		
        accountBean.setDateOfOpening(dateOfOpening);
		
		System.out.println("Deposit some amount to open the account:");
		double balance=scanner.nextDouble();
        accountBean.setBalance(balance);
        
        accountBean.setCustomer(customer);
        
       boolean result=service.createAccount(accountBean);
       
       if(result){
    	   System.out.println("Account Successfully created with "+"\n"+"Account Id:"+accountBean.getAccountId()+"\n"+"Initial Balance:"+accountBean.getBalance());
       }
       else{
    	   System.out.println("Enter valid details");
       }
	}
	
	void showBalance(){
		System.out.println("Enter accountId:");
		int accountId=scanner.nextInt();
		
	    accountBean=service.showBalance(accountId);
	    if(accountBean!=null){
	    	System.out.println("Account Balance is:"+accountBean.getBalance());
	    }else{
	    	System.out.println("Enter valid accountId");
	    }
		
	}
	
	void deposit(){
		
		System.out.println("Enter the accountId");
		int accountId=scanner.nextInt();
		
		accountBean=service.find(accountId);
		if(accountBean!=null){
		System.out.println("Enter the amount to be deposited:");
		double depositAmount=scanner.nextDouble();
		
		
        boolean result=service.deposit(accountBean, accountId, depositAmount);		
	    if(result){
	    	 
	        WalletTransactions wallet=new WalletTransactions();
			wallet.setTransactionType(1);
			wallet.setTransactionDate(new Date());
			wallet.setTransactionAmt(depositAmount);
			wallet.setBeneficiaryAccountBean(null);
			accountBean.addTransaction(wallet);
	        System.out.println("Deposited money into account");

	    }
	    else{
	    	System.out.println("Money not deposited into account");
	    }
		}
		else{
			System.out.println("Account with Account Id:"+accountId+" not found");
		}
	
	}
	
	
	void withdraw(){
		
		System.out.println("Enter Account ID");
		int accountId=scanner.nextInt();
		
	
		accountBean=service.find(accountId);
		if(accountBean!=null){
		System.out.println("Enter amount that you want to withdraw");
		double withdrawAmount=scanner.nextDouble();
		boolean result=service.withdraw(accountBean, accountId, withdrawAmount);	
		
		if(result){
		WalletTransactions wallet=new WalletTransactions();
		wallet.setTransactionType(2);
		wallet.setTransactionDate(new Date());
		wallet.setTransactionAmt(withdrawAmount);
		wallet.setBeneficiaryAccountBean(null);
		
		accountBean.addTransaction(wallet);
		
		System.out.println("Withdraw done successfully");
		}
		else{
			System.out.println("Amount not withdrawn");
		}
		}
		else{
			System.out.println("Account with Account Id:"+accountId+" not found");
		}
			
	}
	
	void fundTransfer(){
		System.out.println("Enter Account ID to Transfer Money From");
		int srcAccountId=scanner.nextInt();
		
		AccountBean accountBean1=service.find(srcAccountId);
		
		System.out.println("Enter Account ID to Transfer Money to");
		int targetAccId=scanner.nextInt();
		
		AccountBean accountBean2=service.find(targetAccId);
		
		System.out.println("Enter amount that you want to transfer");
		double transferAmount=scanner.nextDouble();
		
		
		boolean result=service.fundTransfer(accountBean1, accountBean2, transferAmount);
		
		if(result){
			System.out.println("Transfering Money from Account done");
			WalletTransactions wallet=new WalletTransactions();
			wallet.setTransactionType(3);
			wallet.setTransactionDate(new Date());
			wallet.setTransactionAmt(transferAmount);
			wallet.setBeneficiaryAccountBean(accountBean2);
			
			accountBean1.addTransaction(wallet);
			
		}else{
			System.out.println("Transfering Money from Account Failed ");
		}
		
	}
	
	
	void printTransaction(){
		System.out.println("Enter Account ID (for printing Transaction Details");
		int accountId=scanner.nextInt();
		
		AccountBean accountBean=service.find(accountId);
		
		List<WalletTransactions>  transactions=accountBean.getWalletTransactions();
		
		System.out.println(accountBean);
		System.out.println(accountBean.getCustomer());
		
		System.out.println("------------------------------------------------------------------");
		
		for(WalletTransactions wallet:transactions){
			
			String str="";
			if(wallet.getTransactionType()==1){
				str=str+"DEPOSIT";
			}
			if(wallet.getTransactionType()==2){
				str=str+"WITHDRAW";
			}
			if(wallet.getTransactionType()==3){
				str=str+"FUND TRANSFER";
			}
			
			str=str+"\t\t"+wallet.getTransactionDate();
			
			str=str+"\t\t"+wallet.getTransactionAmt();
			System.out.println(str);
		}
		
		System.out.println("------------------------------------------------------------------");
	

	}
	
}
