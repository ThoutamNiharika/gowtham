package com.cg.paymentwallet.bean;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

	@Entity
	@Table(name="Bank_Accounts1")
	public class AccountBean {
		
		@Id
		private int accountId;
		
		
		private double balance;
		
		@OneToOne(cascade=CascadeType.ALL, fetch=FetchType.EAGER)
		private Customer customer;
		
		@Temporal(TemporalType.DATE)
		private Date dateOfOpening;
		
		@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.EAGER)
		private List<WalletTransactions> walletTransactions;

		public int getAccountId() {
			return accountId;
		}

		public void setAccountId(int accountId) {
			this.accountId = accountId;
		}

		public double getBalance() {
			return balance;
		}

		public void setBalance(double balance) {
			this.balance = balance;
		}

		public Customer getCustomer() {
			return customer;
		}

		public void setCustomer(Customer customer) {
			this.customer = customer;
		}

		public Date getDateOfOpening() {
			return dateOfOpening;
		}

		public void setDateOfOpening(Date dateOfOpening) {
			this.dateOfOpening = dateOfOpening;
		}


		public List<WalletTransactions> getWalletTransactions() {
			return walletTransactions;
		}

		public void setWalletTransactions(List<WalletTransactions> walletTransactions) {
			this.walletTransactions = walletTransactions;
		}

		@Override
		public String toString() {
			return "AccountBean [accountId=" + accountId + ", balance="
					+ balance + ", customer=" + customer + ", dateOfOpening="
					+ dateOfOpening + ", initialDeposit=" + ", walletTransactions=" + walletTransactions + "]";
		}

		public AccountBean() {
			super();
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + accountId;
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			AccountBean other = (AccountBean) obj;
			if (accountId != other.accountId)
				return false;
			return true;
		}

		public void addTransaction(WalletTransactions wallet){
			this.walletTransactions.add(wallet);
		}
		

}
