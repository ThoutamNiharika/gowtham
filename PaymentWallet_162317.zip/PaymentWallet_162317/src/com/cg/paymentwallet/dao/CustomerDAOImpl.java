package com.cg.paymentwallet.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.paymentwallet.bean.AccountBean;

public class CustomerDAOImpl implements ICustomerDAO {

	@Override
	public boolean createAccount(AccountBean accountBean) {
		// TODO Auto-generated method stub
	try{	
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager manager=factory.createEntityManager();
		
		manager.getTransaction().begin();
		manager.persist(accountBean);
		manager.getTransaction().commit();
		
		manager.close();
		factory.close();
		return true;
	}catch(Exception e){
		e.printStackTrace();
	return false;
	}
	}

	@Override
	public AccountBean showBalance(int accountId) {
		// TODO Auto-generated method stub
		try{
			EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager manager=factory.createEntityManager();
			
			manager.getTransaction().begin();
			AccountBean accountBean=manager.find(AccountBean.class, accountId);
			accountBean.setBalance(accountBean.getBalance());
			manager.getTransaction().commit();
			
			manager.close();
			factory.close();
		    return accountBean;
		}
		catch(Exception e){
			e.printStackTrace();
		    return null;
		}


	}

	@Override
	public boolean deposit(AccountBean accountBean,int accountId, double depositAmount) {
		// TODO Auto-generated method stub
		try{
			EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager manager=factory.createEntityManager();
			
			manager.getTransaction().begin();
			AccountBean accountBean1=manager.find(AccountBean.class, accountId);
			accountBean1.setBalance(accountBean.getBalance()+depositAmount);
			manager.getTransaction().commit();
			
			
			manager.close();
			factory.close();
			return true;
		}
		catch(Exception e){
			return false;	
		}
		
	}

	@Override
	public boolean withdraw(AccountBean accountBean,int accountId,double withdrawAmount) {
		// TODO Auto-generated method stub
		try{
			EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager manager=factory.createEntityManager();
			
			manager.getTransaction().begin();
			AccountBean accountBean2=manager.find(AccountBean.class, accountId);
			accountBean2.setBalance(accountBean.getBalance()-withdrawAmount);
			manager.getTransaction().commit();
			
			
			manager.close();
			factory.close();
		    return true;
		}
		catch(Exception e){
			return false;	
		}
		
	}

	@Override
	public boolean fundTransfer(AccountBean toAccountBean,
			AccountBean fromAccountBean, double amount) {
		// TODO Auto-generated method stub
		try{
			EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager manager=factory.createEntityManager();
			
			manager.getTransaction().begin();
			toAccountBean=manager.find(AccountBean.class, toAccountBean.getAccountId());
		    toAccountBean.setBalance(toAccountBean.getBalance()-amount);
		    fromAccountBean=manager.find(AccountBean.class,fromAccountBean.getAccountId());
		    fromAccountBean.setBalance(fromAccountBean.getBalance()+amount);
		    manager.getTransaction().commit();
		    
		    manager.close();
		    factory.close();
		    return true;
		}catch(Exception e) {
		return false;
		}
		}

	@Override
	public AccountBean find(int accountId) {
		// TODO Auto-generated method stub
		try{
			EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager manager=factory.createEntityManager();
			
			manager.getTransaction().begin();
			AccountBean accountBean=manager.find(AccountBean.class, accountId);
			manager.getTransaction().commit();
			
			
			manager.close();
			factory.close();
			return accountBean;
		}
		catch(Exception e){
			return null;
		}
	}

	

	

}
