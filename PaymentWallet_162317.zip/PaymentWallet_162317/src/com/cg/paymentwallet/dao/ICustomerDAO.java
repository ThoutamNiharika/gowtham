package com.cg.paymentwallet.dao;

import com.cg.paymentwallet.bean.AccountBean;

public interface ICustomerDAO {

	public boolean createAccount(AccountBean accountBean);
	
	public AccountBean showBalance(int accountId);
	
	public	boolean deposit(AccountBean accountBean,int accountId,double depositAmount);
		
	public	boolean withdraw(AccountBean accountBean,int accountId,double withdrawAmount);
		
	public	boolean fundTransfer(AccountBean toAccountBean,AccountBean fromAccountBean,double amount);
	
	public AccountBean find(int accountId);

}
