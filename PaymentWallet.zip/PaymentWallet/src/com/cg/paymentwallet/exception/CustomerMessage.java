package com.cg.paymentwallet.exception;

public class CustomerMessage extends CustomerException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String ACCNUMBERERROR="Account Id should not  be zero";
	public static final String FNAMEERROR1="first name should not be empty";
	public static final String FNAMEERROR2="first name should only contain alphabets";
	public static final String MOBILENUMERROR1="mobile number should not contain alphabets";
	public static final String MOBILENUMERROR2="mobile number should contain 10 numbers";
	public static final String PANNUMERROR="pan number should not be empty";
	public static final String ADDRESSERROR="address field should not be empty";
	public static final String EMAILERROR="Email id should not be empty";
}
