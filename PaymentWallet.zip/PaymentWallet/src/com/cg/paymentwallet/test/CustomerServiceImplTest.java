package com.cg.paymentwallet.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.paymentwallet.bean.AccountBean;
import com.cg.paymentwallet.bean.Customer;
import com.cg.paymentwallet.exception.CustomerException;
import com.cg.paymentwallet.service.CustomerServiceImpl;
import com.cg.paymentwallet.service.ICustomerService;

public class CustomerServiceImplTest {

	static ICustomerService service=null;
	
	@BeforeClass
	public static void createInstance(){
		service=new CustomerServiceImpl();
	}
	
	@Test(expected=CustomerException.class)
	public void testCreateAccountForAccountId() throws CustomerException {
		Customer customer=new Customer();
		customer.setFirstName("Gowtham");
		customer.setLastName("Mandava");
		customer.setMobileNumber("9030113454");
		customer.setPanNum("ABCD123456");
		customer.setEmailId("gowtham@gmail.com");
		customer.setAddress("chennai");
		AccountBean accountBean=new AccountBean();
		accountBean.setAccountId(0);
		accountBean.setCustomer(customer);
		boolean result=service.createAccount(accountBean);
		assertFalse(result);
	}

	@Test(expected=CustomerException.class)
	public void testCreateAccountForFirstName() throws CustomerException {
		Customer customer=new Customer();
		customer.setFirstName(" ");
		customer.setLastName("Mandava");
		customer.setMobileNumber("9030113454");
		customer.setPanNum("ABCD123456");
		customer.setEmailId("gowtham@gmail.com");
		customer.setAddress("chennai");
		AccountBean accountBean=new AccountBean();
		accountBean.setAccountId(120);
		accountBean.setCustomer(customer);
		boolean result=service.createAccount(accountBean);
		assertFalse(result);
	}
	
	@Test(expected=CustomerException.class)
	public void testFirstNameForAlpha() throws CustomerException {
		Customer customer=new Customer();
		customer.setFirstName("123");
		customer.setLastName("Mandava");
		customer.setMobileNumber("9030113454");
		customer.setPanNum("ABCD123456");
		customer.setEmailId("gowtham@gmail.com");
		customer.setAddress("chennai");
		AccountBean accountBean=new AccountBean();
		accountBean.setAccountId(120);
		accountBean.setCustomer(customer);
		boolean result=service.createAccount(accountBean);
		assertFalse(result);
	}
	
	@Test(expected=CustomerException.class)
	public void testMobileNumberForAlpha() throws CustomerException {
		Customer customer=new Customer();
		customer.setFirstName("Gowtham");
		customer.setLastName("Mandava");
		customer.setMobileNumber("abcd");
		customer.setPanNum("ABCD123456");
		customer.setEmailId("gowtham@gmail.com");
		customer.setAddress("chennai");
		AccountBean accountBean=new AccountBean();
		accountBean.setAccountId(120);
		accountBean.setCustomer(customer);
		boolean result=service.createAccount(accountBean);
		assertFalse(result);
	}
	
	@Test(expected=CustomerException.class)
	public void testMobileNumber() throws CustomerException {
		Customer customer=new Customer();
		customer.setFirstName("Gowtham");
		customer.setLastName("Mandava");
		customer.setMobileNumber("903011345");
		customer.setPanNum("ABCD123456");
		customer.setEmailId("gowtham@gmail.com");
		customer.setAddress("chennai");
		AccountBean accountBean=new AccountBean();
		accountBean.setAccountId(120);
		accountBean.setCustomer(customer);
		boolean result=service.createAccount(accountBean);
		assertFalse(result);
	}
}
